import React, { useState } from 'react';
import { Trash2, Plus, ArrowLeftRight, Save } from 'lucide-react';

interface Stone {
  id: number;
  name: string;
  image: string;
  rarity: 'Common' | 'Rare' | 'Very Rare' | 'Legendary';
  estimatedValue: string;
  hardness: string;
  composition: string;
  location: string;
}

const availableStones: Stone[] = [
  {
    id: 1,
    name: 'Amethyst',
    image: 'https://images.pexels.com/photos/5368818/pexels-photo-5368818.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Common',
    estimatedValue: '$20-$50',
    hardness: '7 on the Mohs scale',
    composition: 'Silicon dioxide (SiO2) with iron impurities',
    location: 'Brazil, Uruguay, Zambia'
  },
  {
    id: 2,
    name: 'Emerald',
    image: 'https://images.pexels.com/photos/163116/pexel-photo-163116.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Rare',
    estimatedValue: '$500-$1,500',
    hardness: '7.5-8 on the Mohs scale',
    composition: 'Beryllium aluminium silicate with chromium',
    location: 'Colombia, Brazil, Zambia'
  },
  {
    id: 3,
    name: 'Ruby',
    image: 'https://images.pexels.com/photos/4940404/pexels-photo-4940404.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Very Rare',
    estimatedValue: '$1,000-$3,000',
    hardness: '9 on the Mohs scale',
    composition: 'Aluminum oxide with chromium',
    location: 'Myanmar, Thailand, Sri Lanka'
  },
  {
    id: 4,
    name: 'Diamond',
    image: 'https://images.pexels.com/photos/68740/diamond-gem-cubic-zirconia-jewel-68740.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Legendary',
    estimatedValue: '$5,000-$50,000',
    hardness: '10 on the Mohs scale',
    composition: 'Pure carbon',
    location: 'South Africa, Russia, Botswana'
  },
  {
    id: 5,
    name: 'Rose Quartz',
    image: 'https://images.pexels.com/photos/5368778/pexels-photo-5368778.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Common',
    estimatedValue: '$15-$30',
    hardness: '7 on the Mohs scale',
    composition: 'Silicon dioxide with titanium',
    location: 'Brazil, Madagascar, South Dakota'
  },
  {
    id: 6,
    name: 'Tanzanite',
    image: 'https://images.pexels.com/photos/11428623/pexels-photo-11428623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Very Rare',
    estimatedValue: '$500-$2,000',
    hardness: '6-7 on the Mohs scale',
    composition: 'Calcium aluminium silicate with vanadium',
    location: 'Tanzania (exclusively)'
  }
];

const ComparePage: React.FC = () => {
  const [selectedStones, setSelectedStones] = useState<Stone[]>([]);
  const [comparisonSaved, setComparisonSaved] = useState(false);

  const addStone = (stone: Stone) => {
    if (selectedStones.length < 3 && !selectedStones.some(s => s.id === stone.id)) {
      setSelectedStones([...selectedStones, stone]);
      setComparisonSaved(false);
    }
  };

  const removeStone = (stoneId: number) => {
    setSelectedStones(selectedStones.filter(stone => stone.id !== stoneId));
    setComparisonSaved(false);
  };

  const saveComparison = () => {
    // In a real app, this would save to a database or local storage
    setComparisonSaved(true);
    setTimeout(() => setComparisonSaved(false), 3000);
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'Common':
        return 'bg-gray-500 text-white';
      case 'Rare':
        return 'bg-blue-500 text-white';
      case 'Very Rare':
        return 'bg-purple-500 text-white';
      case 'Legendary':
        return 'bg-amber-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  return (
    <div className="pt-24 pb-16 bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">Compare Stones</h1>
          <p className="text-gray-600 mb-8">
            Select up to three stones to compare their properties, value, and rarity.
          </p>
          
          {/* Selected Stones for Comparison */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold flex items-center">
                  <ArrowLeftRight size={20} className="mr-2 text-primary-500" />
                  Stone Comparison
                </h2>
                {selectedStones.length > 0 && (
                  <button
                    onClick={saveComparison}
                    className="flex items-center px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors text-sm font-medium"
                  >
                    <Save size={16} className="mr-2" />
                    Save Comparison
                  </button>
                )}
              </div>
              
              {comparisonSaved && (
                <div className="bg-success-100 text-success-800 p-3 rounded-lg mb-4 animate-fade-in">
                  Comparison saved to your collection!
                </div>
              )}
              
              {selectedStones.length === 0 ? (
                <div className="text-center py-10 text-gray-500">
                  <p>Select stones from below to compare them</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {selectedStones.map(stone => (
                    <div key={stone.id} className="relative bg-gray-50 rounded-lg overflow-hidden border border-gray-200">
                      <button
                        onClick={() => removeStone(stone.id)}
                        className="absolute top-2 right-2 p-1.5 bg-white rounded-full shadow-md text-gray-500 hover:text-error-500 transition-colors"
                        aria-label={`Remove ${stone.name}`}
                      >
                        <Trash2 size={16} />
                      </button>
                      
                      <div className="h-40">
                        <img 
                          src={stone.image} 
                          alt={stone.name} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      <div className="p-4">
                        <h3 className="text-lg font-semibold mb-1">{stone.name}</h3>
                        <div 
                          className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium mb-3 ${getRarityColor(stone.rarity)}`}
                        >
                          {stone.rarity}
                        </div>
                        
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Value:</span>
                            <span className="font-medium">{stone.estimatedValue}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Hardness:</span>
                            <span className="font-medium">{stone.hardness}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Origin:</span>
                            <span className="font-medium">{stone.location.split(',')[0]}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {/* Empty slots */}
                  {Array.from({ length: 3 - selectedStones.length }).map((_, i) => (
                    <div key={i} className="rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center h-64">
                      <div className="text-center text-gray-400">
                        <Plus size={24} className="mx-auto mb-2" />
                        <p>Add stone to compare</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            {selectedStones.length > 1 && (
              <div className="border-t border-gray-200 p-6">
                <h3 className="text-lg font-semibold mb-4">Comparison Analysis</h3>
                
                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2">Rarity Comparison</h4>
                    <div className="bg-gray-100 p-4 rounded-lg">
                      <div className="flex items-center mb-4">
                        <div className="w-32 flex-shrink-0 font-medium">Stone</div>
                        <div className="flex-grow">
                          <div className="h-6 bg-gray-200 rounded-full overflow-hidden">
                            {/* Visual rarity meter */}
                          </div>
                        </div>
                      </div>
                      
                      {selectedStones.map(stone => {
                        const rarityPercentage = 
                          stone.rarity === 'Common' ? 25 :
                          stone.rarity === 'Rare' ? 50 :
                          stone.rarity === 'Very Rare' ? 75 : 100;
                        
                        const rarityColor = 
                          stone.rarity === 'Common' ? 'bg-gray-500' :
                          stone.rarity === 'Rare' ? 'bg-blue-500' :
                          stone.rarity === 'Very Rare' ? 'bg-purple-500' : 'bg-amber-500';
                        
                        return (
                          <div key={stone.id} className="flex items-center mb-2">
                            <div className="w-32 flex-shrink-0">{stone.name}</div>
                            <div className="flex-grow">
                              <div className="h-6 bg-gray-200 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full ${rarityColor} transition-all`} 
                                  style={{ width: `${rarityPercentage}%` }}
                                ></div>
                              </div>
                            </div>
                            <div className="w-24 pl-3 text-sm font-medium">{stone.rarity}</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2">Value Range</h4>
                    <div className="bg-gray-100 p-4 rounded-lg">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {selectedStones.map(stone => {
                          // Extract numeric value from price range
                          const maxValue = parseInt(stone.estimatedValue.split('$')[2]?.split(',').join('') || '0');
                          const percentage = Math.min(maxValue / 500, 100);
                          
                          return (
                            <div key={stone.id} className="text-center">
                              <p className="font-medium mb-2">{stone.name}</p>
                              <div className="mb-1 flex justify-center">
                                <div className="h-4 w-32 bg-gray-200 rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-green-500" 
                                    style={{ width: `${percentage}%` }}
                                  ></div>
                                </div>
                              </div>
                              <p className="text-sm">{stone.estimatedValue}</p>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2">Composition Comparison</h4>
                    <div className="bg-gray-100 p-4 rounded-lg">
                      <div className="space-y-3">
                        {selectedStones.map(stone => (
                          <div key={stone.id} className="flex">
                            <div className="w-32 flex-shrink-0 font-medium">{stone.name}</div>
                            <div>{stone.composition}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Available Stones */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="p-6">
              <h2 className="text-xl font-semibold mb-6">Available Stones</h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {availableStones.map(stone => (
                  <div 
                    key={stone.id} 
                    className={`rounded-xl overflow-hidden shadow-sm border transition-all ${
                      selectedStones.some(s => s.id === stone.id)
                        ? 'border-primary-500 bg-primary-50'
                        : 'border-gray-200 bg-white hover:border-gray-300'
                    }`}
                  >
                    <div className="h-44 relative">
                      <img 
                        src={stone.image} 
                        alt={stone.name} 
                        className="w-full h-full object-cover"
                      />
                      <div 
                        className={`absolute top-2 right-2 ${getRarityColor(stone.rarity)} text-xs font-medium px-2 py-0.5 rounded-full`}
                      >
                        {stone.rarity}
                      </div>
                    </div>
                    
                    <div className="p-4">
                      <h3 className="text-lg font-semibold mb-2">{stone.name}</h3>
                      <p className="text-gray-600 mb-4">{stone.estimatedValue}</p>
                      
                      <button
                        onClick={() => addStone(stone)}
                        disabled={selectedStones.some(s => s.id === stone.id) || selectedStones.length >= 3}
                        className={`w-full py-2 rounded-lg font-medium transition-colors ${
                          selectedStones.some(s => s.id === stone.id)
                            ? 'bg-primary-100 text-primary-500 cursor-not-allowed'
                            : selectedStones.length >= 3
                              ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                              : 'bg-primary-500 hover:bg-primary-600 text-white'
                        }`}
                      >
                        {selectedStones.some(s => s.id === stone.id)
                          ? 'Selected'
                          : selectedStones.length >= 3
                            ? 'Max Stones Selected'
                            : 'Add to Comparison'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComparePage;