import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Heart, Share2, Download, Plus, Minus, BarChart3, PanelTop, MapPin, Info, AlertCircle } from 'lucide-react';
import StoneRarityChart from '../components/stone/StoneRarityChart';
import AlternativeStonesSection from '../components/stone/AlternativeStonesSection';
import StoneDetailSection from '../components/stone/StoneDetailSection';

const stones = {
  '1': {
    name: 'Amethyst',
    images: ['https://images.pexels.com/photos/5368818/pexels-photo-5368818.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'],
    rarity: 'Common',
    estimatedValue: '$20-$50',
    description: 'Amethyst is a purple variety of quartz and is one of the most popular gemstones. The name comes from the Ancient Greek "amethystos", referring to the belief that the stone protected its owner from intoxication.',
    composition: 'Silicon dioxide (SiO2) with iron impurities',
    hardness: '7 on the Mohs scale',
    location: 'Brazil, Uruguay, Zambia, South Korea',
    uses: 'Jewelry, decorative objects, healing crystals',
    history: 'Amethyst has been highly valued throughout history. In ancient Egypt, it was used in burial tombs. The ancient Greeks believed it could prevent intoxication, and medieval European soldiers wore it as protection in battle. Until the 18th century, amethyst was valued similarly to sapphires and rubies before large deposits were found in Brazil.'
  },
  '2': {
    name: 'Emerald',
    images: ['https://images.pexels.com/photos/163116/pexel-photo-163116.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'],
    rarity: 'Rare',
    estimatedValue: '$500-$1,500',
    description: 'Emerald is a gemstone and a variety of the mineral beryl colored green by trace amounts of chromium and sometimes vanadium. It is considered one of the traditional "Big Four" precious gemstones alongside diamond, ruby, and sapphire.',
    composition: 'Beryllium aluminium silicate with chromium and vanadium',
    hardness: '7.5-8 on the Mohs scale',
    location: 'Colombia, Brazil, Zambia, Zimbabwe',
    uses: 'Fine jewelry, investment stones, royal collections',
    history: 'The first known emerald mines were in Egypt, dating from at least 330 BC. Cleopatra was known to have a passion for emeralds and used them in her royal adornments. The Spanish conquistadors discovered rich emerald deposits in Colombia which they exploited in the 16th century, introducing these gems to Europe where they were highly valued by royalty and the wealthy elite.'
  },
  '3': {
    name: 'Ruby',
    images: ['https://images.pexels.com/photos/4940404/pexels-photo-4940404.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'],
    rarity: 'Very Rare',
    estimatedValue: '$1,000-$3,000',
    description: 'Ruby is a pink to blood-red colored gemstone, a variety of the mineral corundum. Ruby is one of the traditional cardinal gems, alongside amethyst, sapphire, emerald, and diamond.',
    composition: 'Aluminum oxide with chromium',
    hardness: '9 on the Mohs scale',
    location: 'Myanmar, Thailand, Sri Lanka, Madagascar',
    uses: 'Fine jewelry, watches, laser technology',
    history: 'Throughout history, rubies have been considered one of the most valuable gemstones. In ancient India, rubies were called "ratnaraj" or "king of precious stones." Burmese warriors believed that rubies made them invincible in battle. In medieval Europe, royalty and nobility wore rubies because they symbolized wealth and power. Some ancient cultures believed that rubies contained the spark of life or an eternal flame.'
  },
  '4': {
    name: 'Diamond',
    images: ['https://images.pexels.com/photos/68740/diamond-gem-cubic-zirconia-jewel-68740.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'],
    rarity: 'Legendary',
    estimatedValue: '$5,000-$50,000',
    description: 'Diamond is a solid form of carbon with a diamond cubic crystal structure. At room temperature and pressure, it is metastable and graphite is the stable form of carbon, but diamond converts to graphite extremely slowly.',
    composition: 'Pure carbon',
    hardness: '10 on the Mohs scale (hardest natural material)',
    location: 'South Africa, Russia, Botswana, Canada',
    uses: 'Engagement rings, fine jewelry, industrial cutting tools',
    history: 'Diamonds have been treasured as gemstones since their use in India at least 3,000 years ago. The popularity of diamonds has risen since the 19th century because of increased supply, improved cutting and polishing techniques, and successful advertising campaigns. In 1866, the discovery of diamonds in Kimberley, South Africa, led to a diamond rush and massive expansion in supply. The renowned diamond company De Beers was established in 1888 and successfully ran the powerful "A Diamond is Forever" marketing campaign beginning in 1947.'
  }
};

const getRarityColor = (rarity: string) => {
  switch (rarity) {
    case 'Common':
      return 'bg-gray-500 text-white';
    case 'Rare':
      return 'bg-blue-500 text-white';
    case 'Very Rare':
      return 'bg-purple-500 text-white';
    case 'Legendary':
      return 'bg-amber-500 text-white';
    default:
      return 'bg-gray-500 text-white';
  }
};

const StonePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const stone = stones[id as keyof typeof stones];
  const [isInCollection, setIsInCollection] = useState(false);
  const [selectedImage, setSelectedImage] = useState(0);
  const [zoomLevel, setZoomLevel] = useState(1);

  if (!stone) {
    return (
      <div className="container mx-auto px-4 py-20 flex flex-col items-center justify-center min-h-screen">
        <AlertCircle size={48} className="text-error-500 mb-4" />
        <h1 className="text-2xl font-bold mb-4">Stone Not Found</h1>
        <p className="text-gray-600 mb-6">The stone you're looking for doesn't exist in our database.</p>
        <a 
          href="/" 
          className="px-6 py-3 bg-primary-500 hover:bg-primary-600 text-white rounded-lg font-medium transition-colors"
        >
          Return Home
        </a>
      </div>
    );
  }

  const toggleCollection = () => {
    setIsInCollection(!isInCollection);
  };

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(prev + 0.25, 2.5));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(prev - 0.25, 1));
  };

  return (
    <div className="pt-16 pb-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Stone Image and Basic Info */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
            <div className="md:flex">
              <div className="md:w-1/2 p-6 relative">
                <div className="relative h-80 md:h-96 overflow-hidden rounded-lg bg-gray-100 flex items-center justify-center">
                  <img 
                    src={stone.images[selectedImage]} 
                    alt={stone.name} 
                    className="transition-transform duration-300 object-cover"
                    style={{ transform: `scale(${zoomLevel})` }}
                  />
                  <div className="absolute bottom-4 right-4 flex bg-white rounded-lg shadow-md">
                    <button 
                      onClick={handleZoomOut}
                      className="p-2 text-gray-600 hover:text-gray-900 disabled:text-gray-300"
                      disabled={zoomLevel <= 1}
                    >
                      <Minus size={16} />
                    </button>
                    <button 
                      onClick={handleZoomIn}
                      className="p-2 text-gray-600 hover:text-gray-900 disabled:text-gray-300"
                      disabled={zoomLevel >= 2.5}
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                </div>
                
                {stone.images.length > 1 && (
                  <div className="flex mt-4 space-x-2">
                    {stone.images.map((img, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedImage(index)}
                        className={`w-16 h-16 rounded-md overflow-hidden border-2 transition-all ${
                          selectedImage === index ? 'border-primary-500' : 'border-transparent'
                        }`}
                      >
                        <img 
                          src={img} 
                          alt={`${stone.name} view ${index + 1}`} 
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                )}
              </div>
              
              <div className="md:w-1/2 p-6 md:border-l border-gray-200">
                <div className="flex justify-between items-start">
                  <div>
                    <h1 className="text-3xl font-bold mb-2">{stone.name}</h1>
                    <div className="flex items-center mb-4">
                      <span 
                        className={`px-3 py-1 rounded-full text-sm font-medium ${getRarityColor(stone.rarity)}`}
                      >
                        {stone.rarity}
                      </span>
                      <span className="ml-3 flex items-center text-gray-500">
                        <MapPin size={14} className="mr-1" />
                        {stone.location.split(',')[0]}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <button
                      onClick={toggleCollection}
                      className={`p-2 rounded-full transition-colors ${
                        isInCollection 
                          ? 'bg-primary-100 text-primary-500' 
                          : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                      }`}
                      aria-label="Toggle collection"
                    >
                      <Heart size={20} className={isInCollection ? 'fill-current' : ''} />
                    </button>
                    <button
                      className="p-2 rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 transition-colors"
                      aria-label="Share"
                    >
                      <Share2 size={20} />
                    </button>
                    <button
                      className="p-2 rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 transition-colors"
                      aria-label="Download information"
                    >
                      <Download size={20} />
                    </button>
                  </div>
                </div>
                
                <div className="mt-8">
                  <div className="flex items-center justify-between mb-4 pb-4 border-b border-gray-200">
                    <div>
                      <span className="text-sm text-gray-500">Estimated Value</span>
                      <h3 className="text-2xl font-bold">{stone.estimatedValue}</h3>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Hardness</span>
                      <h3 className="text-xl font-semibold">{stone.hardness}</h3>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Common Use</span>
                      <h3 className="text-xl font-semibold">{stone.uses.split(',')[0]}</h3>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-6">{stone.description}</p>
                  
                  <div className="flex flex-wrap gap-3">
                    <a
                      href="/compare"
                      className="flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 transition-colors text-sm font-medium"
                    >
                      <PanelTop size={16} />
                      Compare with other stones
                    </a>
                    <button
                      className="flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 transition-colors text-sm font-medium"
                    >
                      <BarChart3 size={16} />
                      View market trend
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <StoneDetailSection stone={stone} />
            </div>
            
            <div className="lg:col-span-1">
              <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-4 flex items-center">
                    <BarChart3 size={20} className="mr-2 text-primary-500" />
                    Rarity & Value Trend
                  </h3>
                  <StoneRarityChart stoneName={stone.name} />
                </div>
              </div>
              
              <div className="bg-white rounded-xl shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-4 flex items-center">
                    <Info size={20} className="mr-2 text-primary-500" />
                    Quick Facts
                  </h3>
                  <ul className="space-y-3">
                    <li className="flex justify-between">
                      <span className="text-gray-600">Formation</span>
                      <span className="font-medium">Igneous</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-gray-600">Crystal System</span>
                      <span className="font-medium">Trigonal</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-gray-600">Cleavage</span>
                      <span className="font-medium">None</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-gray-600">Transparency</span>
                      <span className="font-medium">Transparent to Translucent</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-gray-600">Luster</span>
                      <span className="font-medium">Vitreous</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          
          <AlternativeStonesSection currentStone={stone.name} />
        </div>
      </div>
    </div>
  );
};

export default StonePage;