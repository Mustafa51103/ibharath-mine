import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Grid, List, Gem, Search, Plus, Star, ArrowUpDown, Filter } from 'lucide-react';

interface CollectionStone {
  id: number;
  name: string;
  image: string;
  rarity: 'Common' | 'Rare' | 'Very Rare' | 'Legendary';
  dateAdded: string;
  notes: string;
  favorite: boolean;
}

// Mock data for demonstration
const initialStones: CollectionStone[] = [
  {
    id: 1,
    name: 'Amethyst',
    image: 'https://images.pexels.com/photos/5368818/pexels-photo-5368818.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Common',
    dateAdded: '2024-03-15',
    notes: 'Found during hiking trip in Colorado',
    favorite: true
  },
  {
    id: 2,
    name: 'Emerald',
    image: 'https://images.pexels.com/photos/163116/pexel-photo-163116.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Rare',
    dateAdded: '2024-02-20',
    notes: 'Gift from grandmother',
    favorite: false
  },
  {
    id: 3,
    name: 'Ruby',
    image: 'https://images.pexels.com/photos/4940404/pexels-photo-4940404.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Very Rare',
    dateAdded: '2024-01-10',
    notes: 'Purchased at gem show',
    favorite: true
  },
  {
    id: 5,
    name: 'Rose Quartz',
    image: 'https://images.pexels.com/photos/5368778/pexels-photo-5368778.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Common',
    dateAdded: '2023-12-05',
    notes: 'Found near river bed',
    favorite: false
  }
];

const CollectionPage: React.FC = () => {
  const [stones, setStones] = useState<CollectionStone[]>(initialStones);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'rarity' | 'date'>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [filterRarity, setFilterRarity] = useState<string | null>(null);

  const toggleFavorite = (id: number) => {
    setStones(stones.map(stone => 
      stone.id === id ? { ...stone, favorite: !stone.favorite } : stone
    ));
  };

  const handleSort = (criteria: 'name' | 'rarity' | 'date') => {
    if (sortBy === criteria) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(criteria);
      setSortDirection('asc');
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'Common':
        return 'bg-gray-500 text-white';
      case 'Rare':
        return 'bg-blue-500 text-white';
      case 'Very Rare':
        return 'bg-purple-500 text-white';
      case 'Legendary':
        return 'bg-amber-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const getRarityValue = (rarity: string) => {
    switch (rarity) {
      case 'Common': return 1;
      case 'Rare': return 2;
      case 'Very Rare': return 3;
      case 'Legendary': return 4;
      default: return 0;
    }
  };

  const filteredAndSortedStones = stones
    .filter(stone => {
      const matchesSearch = stone.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            stone.notes.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRarity = filterRarity ? stone.rarity === filterRarity : true;
      return matchesSearch && matchesRarity;
    })
    .sort((a, b) => {
      let comparison = 0;
      
      if (sortBy === 'name') {
        comparison = a.name.localeCompare(b.name);
      } else if (sortBy === 'rarity') {
        comparison = getRarityValue(a.rarity) - getRarityValue(b.rarity);
      } else if (sortBy === 'date') {
        comparison = new Date(a.dateAdded).getTime() - new Date(b.dateAdded).getTime();
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  return (
    <div className="pt-24 pb-16 bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold mb-2">My Collection</h1>
              <p className="text-gray-600">Manage and organize your stone collection</p>
            </div>
            
            <Link
              to="/"
              className="flex items-center gap-2 px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors text-sm font-medium hidden md:flex"
            >
              <Plus size={16} />
              Add New Stone
            </Link>
          </div>
          
          {/* Mobile Add Button */}
          <div className="md:hidden mb-4">
            <Link
              to="/"
              className="flex items-center justify-center gap-2 w-full px-4 py-3 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors font-medium"
            >
              <Plus size={18} />
              Add New Stone
            </Link>
          </div>
          
          {/* Filters and Search */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
            <div className="p-4 md:p-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="relative w-full md:w-auto md:flex-grow">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                  <input
                    type="text"
                    placeholder="Search your collection..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 w-full py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors"
                  />
                </div>
                
                <div className="flex flex-wrap gap-2 md:gap-4">
                  <div className="relative">
                    <button
                      className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <Filter size={16} />
                      <span className="text-sm">Filter</span>
                    </button>
                    
                    <div className="absolute top-full mt-1 right-0 z-10 bg-white border border-gray-200 rounded-lg shadow-lg py-2 min-w-32">
                      <button
                        onClick={() => setFilterRarity(null)}
                        className={`w-full text-left px-4 py-1.5 text-sm ${filterRarity === null ? 'bg-primary-50 text-primary-600' : 'hover:bg-gray-50'}`}
                      >
                        All Rarities
                      </button>
                      <button
                        onClick={() => setFilterRarity('Common')}
                        className={`w-full text-left px-4 py-1.5 text-sm ${filterRarity === 'Common' ? 'bg-primary-50 text-primary-600' : 'hover:bg-gray-50'}`}
                      >
                        Common
                      </button>
                      <button
                        onClick={() => setFilterRarity('Rare')}
                        className={`w-full text-left px-4 py-1.5 text-sm ${filterRarity === 'Rare' ? 'bg-primary-50 text-primary-600' : 'hover:bg-gray-50'}`}
                      >
                        Rare
                      </button>
                      <button
                        onClick={() => setFilterRarity('Very Rare')}
                        className={`w-full text-left px-4 py-1.5 text-sm ${filterRarity === 'Very Rare' ? 'bg-primary-50 text-primary-600' : 'hover:bg-gray-50'}`}
                      >
                        Very Rare
                      </button>
                      <button
                        onClick={() => setFilterRarity('Legendary')}
                        className={`w-full text-left px-4 py-1.5 text-sm ${filterRarity === 'Legendary' ? 'bg-primary-50 text-primary-600' : 'hover:bg-gray-50'}`}
                      >
                        Legendary
                      </button>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => handleSort('date')}
                    className={`flex items-center gap-2 px-3 py-2 border rounded-lg transition-colors ${
                      sortBy === 'date' ? 'border-primary-500 bg-primary-50 text-primary-600' : 'border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <ArrowUpDown size={16} />
                    <span className="text-sm">Date {sortBy === 'date' && (sortDirection === 'asc' ? '↑' : '↓')}</span>
                  </button>
                  
                  <button
                    onClick={() => handleSort('rarity')}
                    className={`flex items-center gap-2 px-3 py-2 border rounded-lg transition-colors ${
                      sortBy === 'rarity' ? 'border-primary-500 bg-primary-50 text-primary-600' : 'border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <Gem size={16} />
                    <span className="text-sm">Rarity {sortBy === 'rarity' && (sortDirection === 'asc' ? '↑' : '↓')}</span>
                  </button>
                  
                  <div className="flex rounded-lg border border-gray-300 overflow-hidden">
                    <button
                      onClick={() => setViewMode('grid')}
                      className={`p-2 ${viewMode === 'grid' ? 'bg-primary-500 text-white' : 'bg-white text-gray-500 hover:bg-gray-50'}`}
                      aria-label="Grid view"
                    >
                      <Grid size={16} />
                    </button>
                    <button
                      onClick={() => setViewMode('list')}
                      className={`p-2 ${viewMode === 'list' ? 'bg-primary-500 text-white' : 'bg-white text-gray-500 hover:bg-gray-50'}`}
                      aria-label="List view"
                    >
                      <List size={16} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Collection Display */}
          {filteredAndSortedStones.length === 0 ? (
            <div className="bg-white rounded-xl shadow-md overflow-hidden p-8 text-center">
              <Gem size={48} className="mx-auto text-gray-300 mb-4" />
              <h2 className="text-xl font-semibold mb-2">No stones found</h2>
              <p className="text-gray-600 mb-6">
                {searchQuery || filterRarity 
                  ? "Try adjusting your search or filters" 
                  : "Your collection is empty. Add some stones!"}
              </p>
              <Link
                to="/"
                className="inline-flex items-center gap-2 px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors text-sm font-medium"
              >
                <Plus size={16} />
                Add New Stone
              </Link>
            </div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredAndSortedStones.map(stone => (
                <div key={stone.id} className="bg-white rounded-xl shadow-md overflow-hidden stone-card">
                  <div className="relative h-48">
                    <img 
                      src={stone.image} 
                      alt={stone.name} 
                      className="w-full h-full object-cover"
                    />
                    <div 
                      className={`absolute top-3 right-3 ${getRarityColor(stone.rarity)} text-xs font-medium px-2 py-1 rounded-full`}
                    >
                      {stone.rarity}
                    </div>
                    <button
                      onClick={() => toggleFavorite(stone.id)}
                      className={`absolute top-3 left-3 p-1.5 rounded-full ${
                        stone.favorite 
                          ? 'bg-white text-amber-500' 
                          : 'bg-white/70 text-gray-400 hover:bg-white hover:text-amber-500'
                      } transition-colors`}
                    >
                      <Star size={16} className={stone.favorite ? 'fill-current' : ''} />
                    </button>
                  </div>
                  
                  <div className="p-4">
                    <Link to={`/stone/${stone.id}`}>
                      <h3 className="font-semibold text-lg mb-1 hover:text-primary-600 transition-colors">
                        {stone.name}
                      </h3>
                    </Link>
                    
                    <div className="text-sm text-gray-500 mb-3">
                      Added on {new Date(stone.dateAdded).toLocaleDateString()}
                    </div>
                    
                    {stone.notes && (
                      <p className="text-gray-700 text-sm mb-3 line-clamp-2">{stone.notes}</p>
                    )}
                    
                    <div className="flex justify-between items-center">
                      <Link
                        to={`/stone/${stone.id}`}
                        className="text-primary-500 hover:text-primary-600 text-sm font-medium"
                      >
                        View Details
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <ul className="divide-y divide-gray-200">
                {filteredAndSortedStones.map(stone => (
                  <li key={stone.id} className="p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center">
                      <div className="h-16 w-16 flex-shrink-0 rounded-md overflow-hidden mr-4">
                        <img 
                          src={stone.image} 
                          alt={stone.name} 
                          className="h-full w-full object-cover"
                        />
                      </div>
                      
                      <div className="flex-grow min-w-0">
                        <div className="flex items-start justify-between">
                          <div>
                            <Link to={`/stone/${stone.id}`}>
                              <h3 className="font-semibold hover:text-primary-600 transition-colors">
                                {stone.name}
                              </h3>
                            </Link>
                            <div className="text-sm text-gray-500">
                              Added on {new Date(stone.dateAdded).toLocaleDateString()}
                            </div>
                          </div>
                          
                          <div className="flex items-center">
                            <span 
                              className={`${getRarityColor(stone.rarity)} text-xs font-medium px-2 py-0.5 rounded-full mr-2`}
                            >
                              {stone.rarity}
                            </span>
                            <button
                              onClick={() => toggleFavorite(stone.id)}
                              className={`p-1 rounded-full ${
                                stone.favorite 
                                  ? 'text-amber-500' 
                                  : 'text-gray-400 hover:text-amber-500'
                              } transition-colors`}
                            >
                              <Star size={16} className={stone.favorite ? 'fill-current' : ''} />
                            </button>
                          </div>
                        </div>
                        
                        {stone.notes && (
                          <p className="text-gray-700 text-sm mt-1">{stone.notes}</p>
                        )}
                      </div>
                      
                      <Link
                        to={`/stone/${stone.id}`}
                        className="ml-4 text-primary-500 hover:text-primary-600 text-sm font-medium"
                      >
                        View
                      </Link>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CollectionPage;