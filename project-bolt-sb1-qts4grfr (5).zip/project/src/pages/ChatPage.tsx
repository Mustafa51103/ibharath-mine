import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, Gem, PanelTop, BookOpen, DollarSign, Sparkles, Zap } from 'lucide-react';

interface ChatMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const suggestedQuestions = [
  "What's the rarest gemstone in the world?",
  "How can I tell if a diamond is real?",
  "Which region is best known for emeralds?",
  "What makes rubies so valuable?",
  "How are gemstones formed in nature?",
  "What's the difference between a stone and a gem?",
  "How has the value of amethyst changed over time?",
  "What stones are best for beginning collectors?"
];

const ChatPage: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'assistant',
      content: "Hello! I'm your AI assistant for all things related to stones and minerals. Ask me any questions about identification, valuation, origins, or collecting tips. What would you like to know?",
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputMessage.trim()) return;

    const newUserMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newUserMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate assistant response after a delay
    setTimeout(() => {
      const assistantResponse = generateResponse(inputMessage);
      setMessages(prev => [...prev, assistantResponse]);
      setIsTyping(false);
    }, 1000);
  };

  const handleSuggestedQuestion = (question: string) => {
    setInputMessage(question);
    handleSendMessage();
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    
    if (!isRecording) {
      // Start recording
      setTimeout(() => {
        setIsRecording(false);
        setInputMessage("What's the most valuable stone you've seen?");
        handleSendMessage();
      }, 2000);
    }
  };

  // Simple response generator for demo
  const generateResponse = (query: string): ChatMessage => {
    let response = '';
    
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('rarest') || lowerQuery.includes('rare')) {
      response = "The Painite is considered one of the rarest gemstones in the world. First discovered in Myanmar in the 1950s, for decades only a handful of specimens were known to exist. Other extremely rare gems include Red Diamonds, Alexandrite, Benitoite, and Tanzanite (which is found only in one location near Mount Kilimanjaro in Tanzania).";
    } else if (lowerQuery.includes('diamond') && (lowerQuery.includes('real') || lowerQuery.includes('fake'))) {
      response = "To check if a diamond is real, try these simple tests: 1) The fog test - breathe on it, a real diamond will clear immediately. 2) Water test - real diamonds don't float. 3) UV light test - most diamonds will emit a blue fluorescence. 4) Sparkle test - real diamonds reflect light differently than cubic zirconia or glass. However, the most reliable method is to have it evaluated by a professional gemologist using specialized tools.";
    } else if (lowerQuery.includes('emerald') && lowerQuery.includes('region')) {
      response = "Colombia is world-renowned for producing the finest emeralds. The three main mining areas in Colombia - Muzo, Chivor, and Coscuez - are known for emeralds with exceptional color and clarity. Other significant emerald-producing regions include Zambia, Brazil, Zimbabwe, and Russia. Colombian emeralds are particularly prized for their warm, intense green color with a slight bluish tint.";
    } else if (lowerQuery.includes('ruby') && (lowerQuery.includes('valuable') || lowerQuery.includes('value'))) {
      response = "Rubies are valuable due to several factors: 1) Rarity - high-quality rubies are extremely rare. 2) Durability - they rank 9 on the Mohs scale, second only to diamonds. 3) Color - the most valued rubies have a pure, vibrant red color called 'pigeon blood red.' 4) Cultural significance - throughout history, rubies have been associated with power and royalty. The most valuable rubies come from Myanmar (Burma), particularly from the Mogok Valley.";
    } else if (lowerQuery.includes('formed') || lowerQuery.includes('formation')) {
      response = "Gemstones form through various geological processes: 1) Igneous formation - gems like diamonds form under extreme heat and pressure deep in the Earth's mantle. 2) Metamorphic formation - gems like rubies and sapphires form when minerals recrystallize under pressure and heat. 3) Sedimentary formation - opals form when silica-rich water fills cracks in rock. 4) Hydrothermal formation - emeralds and aquamarines can form when mineral-rich hot water cools in rock cavities. These processes typically take millions of years.";
    } else if ((lowerQuery.includes('stone') || lowerQuery.includes('gem')) && lowerQuery.includes('difference')) {
      response = "The main difference between a stone and a gem lies in quality and rarity. A gemstone is a mineral crystal that has been cut and polished for use in jewelry, while 'stone' is a broader term that can refer to any piece of rock. All gems are stones, but not all stones are gems. Gemstones typically possess beauty (color, clarity), durability (hardness, toughness), rarity, and they can be enhanced through cutting and polishing. A rock like limestone wouldn't be considered a gemstone, but a high-quality ruby would.";
    } else if (lowerQuery.includes('amethyst') && lowerQuery.includes('value')) {
      response = "The value of amethyst has changed dramatically over time. In ancient times, it was valued as highly as rubies and sapphires due to its rich purple color and relative rarity. However, in the 19th century, large deposits were discovered in Brazil, making amethyst much more common and significantly reducing its value. Today, amethyst is relatively affordable compared to other precious gemstones, with high-quality specimens typically selling for $20-$50 per carat, though exceptionally large or deeply colored specimens can still command higher prices.";
    } else if (lowerQuery.includes('beginn') && lowerQuery.includes('collect')) {
      response = "For beginning collectors, I'd recommend starting with: 1) Quartz varieties like amethyst, citrine, and rose quartz - they're relatively affordable, durable, and come in various colors. 2) Garnet - reasonably priced with beautiful red to orange hues. 3) Malachite - distinctive green patterns and relatively inexpensive. 4) Fluorite - comes in multiple colors and has interesting fluorescent properties. 5) Agate - durable with beautiful banding patterns. Focus on what attracts you visually, learn about proper storage, and consider joining local mineralogical societies to connect with other collectors.";
    } else if (lowerQuery.includes('valuable') && lowerQuery.includes('seen')) {
      response = "The most valuable stones I've analyzed include: 1) The Pink Star Diamond - sold for $71.2 million at auction, it's a 59.60-carat pink diamond. 2) The Oppenheimer Blue - a 14.62-carat vivid blue diamond that sold for $57.5 million. 3) The Sunrise Ruby - a 25.59-carat Burmese ruby that sold for $30.3 million. These extraordinary stones combine extreme rarity, exceptional color, remarkable size, and historical significance. What makes them particularly valuable is the perfect combination of the 4Cs: color, clarity, cut, and carat weight.";
    } else {
      response = "That's an interesting question about stones and minerals! In a comprehensive database, I'd provide detailed information about geological formation, mineral properties, market valuation, and historical significance. Is there a specific aspect of stones or minerals you'd like to explore further?";
    }

    return {
      id: Date.now().toString(),
      type: 'assistant',
      content: response,
      timestamp: new Date()
    };
  };

  return (
    <div className="pt-16 pb-16 bg-gray-50 min-h-screen flex flex-col">
      <div className="container mx-auto px-4 flex-grow flex flex-col">
        <div className="max-w-4xl mx-auto w-full flex-grow flex flex-col pt-6">
          <div className="bg-white rounded-xl shadow-md overflow-hidden flex-grow flex flex-col">
            {/* Header */}
            <div className="bg-primary-500 text-white p-4">
              <div className="flex items-center">
                <Gem className="w-6 h-6 mr-2" />
                <h1 className="text-xl font-semibold">Stone Expert AI Assistant</h1>
              </div>
              <p className="text-sm text-primary-100 mt-1">
                Ask me anything about stones, gems, minerals, and their value
              </p>
            </div>
            
            {/* Chat Messages */}
            <div className="flex-grow overflow-y-auto p-4 md:p-6 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.type === 'user'
                        ? 'bg-primary-500 text-white rounded-br-none'
                        : 'bg-gray-100 text-gray-800 rounded-bl-none'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{message.content}</p>
                    <div
                      className={`text-xs mt-1 ${
                        message.type === 'user' ? 'text-primary-200' : 'text-gray-500'
                      }`}
                    >
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 text-gray-800 rounded-lg rounded-bl-none p-3 max-w-[80%]">
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 rounded-full bg-gray-500 animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="w-2 h-2 rounded-full bg-gray-500 animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="w-2 h-2 rounded-full bg-gray-500 animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
            
            {/* Suggested Questions */}
            {messages.length < 3 && (
              <div className="px-4 py-3 border-t border-gray-200">
                <p className="text-sm font-medium text-gray-500 mb-2">Suggested questions:</p>
                <div className="flex flex-wrap gap-2">
                  {suggestedQuestions.slice(0, 4).map((question, index) => (
                    <button
                      key={index}
                      onClick={() => handleSuggestedQuestion(question)}
                      className="text-sm bg-gray-100 hover:bg-gray-200 text-gray-800 px-3 py-1.5 rounded-full transition-colors"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Input Area */}
            <div className="border-t border-gray-200 p-4">
              <form onSubmit={handleSendMessage} className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={toggleRecording}
                  className={`p-2 rounded-full flex-shrink-0 transition-colors ${
                    isRecording 
                      ? 'bg-error-100 text-error-500 animate-pulse' 
                      : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                  }`}
                  aria-label="Toggle voice input"
                >
                  <Mic size={20} />
                </button>
                
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Ask about any stone or mineral..."
                  className="flex-grow py-2 px-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors"
                />
                
                <button
                  type="submit"
                  disabled={!inputMessage.trim()}
                  className={`p-2 rounded-full flex-shrink-0 transition-colors ${
                    inputMessage.trim()
                      ? 'bg-primary-500 text-white hover:bg-primary-600'
                      : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                  }`}
                  aria-label="Send message"
                >
                  <Send size={20} />
                </button>
              </form>
            </div>
          </div>
          
          {/* Features */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
              <div className="flex items-center text-primary-500 mb-2">
                <PanelTop size={18} className="mr-2" />
                <h3 className="font-medium">Compare</h3>
              </div>
              <p className="text-sm text-gray-600">
                Ask me to compare different types of stones
              </p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
              <div className="flex items-center text-primary-500 mb-2">
                <BookOpen size={18} className="mr-2" />
                <h3 className="font-medium">Learn</h3>
              </div>
              <p className="text-sm text-gray-600">
                Get detailed information on any stone
              </p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
              <div className="flex items-center text-primary-500 mb-2">
                <DollarSign size={18} className="mr-2" />
                <h3 className="font-medium">Valuation</h3>
              </div>
              <p className="text-sm text-gray-600">
                Learn about pricing and market trends
              </p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
              <div className="flex items-center text-primary-500 mb-2">
                <Sparkles size={18} className="mr-2" />
                <h3 className="font-medium">Collection Tips</h3>
              </div>
              <p className="text-sm text-gray-600">
                Get advice on building your collection
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatPage;