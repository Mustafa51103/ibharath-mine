import React, { useState, useRef } from 'react';
import { Camera, Upload, ArrowRight, Info, X } from 'lucide-react';
import SampleStones from '../components/home/SampleStones';
import FeatureSection from '../components/home/FeatureSection';
import HeroSection from '../components/home/HeroSection';

const HomePage: React.FC = () => {
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
      }
      setShowCamera(true);
    } catch (err) {
      console.error('Error accessing camera:', err);
      alert('Unable to access camera. Please ensure you have granted camera permissions.');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setShowCamera(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);
        canvas.toBlob(blob => {
          if (blob) {
            const file = new File([blob], 'captured-stone.jpg', { type: 'image/jpeg' });
            setSelectedFile(file);
            setPreviewUrl(URL.createObjectURL(file));
            stopCamera();
          }
        }, 'image/jpeg');
      }
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;
    
    setIsUploading(true);
    
    // Simulate upload delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // In a real app, you would upload the file to a server
    // and then redirect to the stone page with the result
    window.location.href = '/stone/1';
    
    setIsUploading(false);
  };

  const clearSelection = () => {
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    setSelectedFile(null);
    setPreviewUrl(null);
  };

  return (
    <div className="pt-16">
      <HeroSection />
      
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-10">
            <h2 className="text-3xl font-bold mb-4">Identify Your Stone</h2>
            <p className="text-gray-600 mb-8">
              Upload a photo or use your camera to identify your stone, learn about its properties, 
              and discover its estimated value.
            </p>
            
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="flex flex-col items-center">
                {!showCamera && !previewUrl && (
                  <div className="flex gap-4 mb-6">
                    <button
                      onClick={startCamera}
                      className="flex items-center gap-2 px-6 py-3 bg-primary-500 hover:bg-primary-600 text-white rounded-lg font-medium transition-colors"
                    >
                      <Camera size={20} />
                      Take Photo
                    </button>
                    <label 
                      htmlFor="stone-upload" 
                      className="flex items-center gap-2 px-6 py-3 bg-white border border-gray-300 hover:bg-gray-50 rounded-lg font-medium cursor-pointer transition-colors"
                    >
                      <Upload size={20} />
                      Upload Photo
                      <input 
                        id="stone-upload" 
                        type="file" 
                        className="hidden" 
                        accept="image/*"
                        onChange={handleFileSelect}
                      />
                    </label>
                  </div>
                )}

                {showCamera && (
                  <div className="relative w-full max-w-md mb-6">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      className="w-full rounded-lg"
                    />
                    <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4">
                      <button
                        onClick={capturePhoto}
                        className="px-6 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg font-medium transition-colors"
                      >
                        Capture
                      </button>
                      <button
                        onClick={stopCamera}
                        className="px-6 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg font-medium transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}

                {previewUrl && (
                  <div className="relative w-full max-w-md mb-6">
                    <img 
                      src={previewUrl} 
                      alt="Selected stone" 
                      className="w-full rounded-lg"
                    />
                    <button
                      onClick={clearSelection}
                      className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-md hover:bg-gray-100 transition-colors"
                    >
                      <X size={20} />
                    </button>
                  </div>
                )}
                
                {selectedFile && (
                  <div className="mb-4 text-center">
                    <p className="text-sm font-medium text-gray-700">
                      Ready to identify your stone
                    </p>
                  </div>
                )}
                
                <button
                  onClick={handleUpload}
                  disabled={!selectedFile || isUploading}
                  className={`flex items-center justify-center gap-2 px-6 py-3 rounded-lg font-medium transition-colors ${
                    selectedFile && !isUploading
                      ? 'bg-primary-500 hover:bg-primary-600 text-white'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  {isUploading ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </>
                  ) : (
                    <>
                      Identify Stone <ArrowRight size={16} />
                    </>
                  )}
                </button>
                
                <div className="mt-4 flex items-center">
                  <Info size={16} className="text-gray-400 mr-2" />
                  <span className="text-xs text-gray-500">
                    Or choose from sample stones below
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <SampleStones />
        </div>
      </section>
      
      <FeatureSection />
    </div>
  );
};

export default HomePage;