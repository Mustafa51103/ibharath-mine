import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import HomePage from './pages/HomePage';
import StonePage from './pages/StonePage';
import ComparePage from './pages/ComparePage';
import CollectionPage from './pages/CollectionPage';
import ChatPage from './pages/ChatPage';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="stone/:id" element={<StonePage />} />
        <Route path="compare" element={<ComparePage />} />
        <Route path="collection" element={<CollectionPage />} />
        <Route path="chat" element={<ChatPage />} />
      </Route>
    </Routes>
  );
}

export default App;