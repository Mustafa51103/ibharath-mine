import React from 'react';
import { Link } from 'react-router-dom';
import { Shuffle, ArrowRight } from 'lucide-react';

interface AlternativeStone {
  id: number;
  name: string;
  image: string;
  rarity: string;
  estimatedValue: string;
  similarityScore: number;
}

interface AlternativeStonesSectionProps {
  currentStone: string;
}

const AlternativeStonesSection: React.FC<AlternativeStonesSectionProps> = ({ currentStone }) => {
  // Mock data - in a real app, this would be generated dynamically based on the current stone
  const getAlternativeStones = (): AlternativeStone[] => {
    switch (currentStone) {
      case 'Amethyst':
        return [
          {
            id: 5,
            name: 'Rose Quartz',
            image: 'https://images.pexels.com/photos/5368778/pexels-photo-5368778.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            rarity: 'Common',
            estimatedValue: '$15-$30',
            similarityScore: 85
          },
          {
            id: 6,
            name: 'Purple Fluorite',
            image: 'https://images.pexels.com/photos/11428623/pexels-photo-11428623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            rarity: 'Common',
            estimatedValue: '$10-$40',
            similarityScore: 78
          },
          {
            id: 7,
            name: 'Lavender Jade',
            image: 'https://images.pexels.com/photos/12387631/pexels-photo-12387631.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            rarity: 'Rare',
            estimatedValue: '$100-$200',
            similarityScore: 65
          }
        ];
      case 'Emerald':
        return [
          {
            id: 8,
            name: 'Green Tourmaline',
            image: 'https://images.pexels.com/photos/4940741/pexels-photo-4940741.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            rarity: 'Rare',
            estimatedValue: '$200-$600',
            similarityScore: 82
          },
          {
            id: 9,
            name: 'Peridot',
            image: 'https://images.pexels.com/photos/2115972/pexels-photo-2115972.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            rarity: 'Common',
            estimatedValue: '$50-$150',
            similarityScore: 75
          },
          {
            id: 10,
            name: 'Green Sapphire',
            image: 'https://images.pexels.com/photos/5368743/pexels-photo-5368743.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            rarity: 'Very Rare',
            estimatedValue: '$800-$1,500',
            similarityScore: 70
          }
        ];
      default:
        return [
          {
            id: 5,
            name: 'Rose Quartz',
            image: 'https://images.pexels.com/photos/5368778/pexels-photo-5368778.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            rarity: 'Common',
            estimatedValue: '$15-$30',
            similarityScore: 85
          },
          {
            id: 6,
            name: 'Purple Fluorite',
            image: 'https://images.pexels.com/photos/11428623/pexels-photo-11428623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            rarity: 'Common',
            estimatedValue: '$10-$40',
            similarityScore: 78
          },
          {
            id: 7,
            name: 'Lavender Jade',
            image: 'https://images.pexels.com/photos/12387631/pexels-photo-12387631.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            rarity: 'Rare',
            estimatedValue: '$100-$200',
            similarityScore: 65
          }
        ];
    }
  };

  const alternativeStones = getAlternativeStones();

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'Common':
        return 'bg-gray-500 text-white';
      case 'Rare':
        return 'bg-blue-500 text-white';
      case 'Very Rare':
        return 'bg-purple-500 text-white';
      case 'Legendary':
        return 'bg-amber-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  return (
    <section className="mt-10 bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold flex items-center">
            <Shuffle size={20} className="mr-2 text-primary-500" />
            Alternative Stones
          </h3>
          <Link to="/compare" className="text-primary-500 hover:text-primary-600 text-sm font-medium flex items-center">
            Compare all <ArrowRight size={16} className="ml-1" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {alternativeStones.map(stone => (
            <Link to={`/stone/${stone.id}`} key={stone.id} className="stone-card rounded-lg overflow-hidden border border-gray-200 hover:border-gray-300 transition-colors">
              <div className="relative h-44">
                <img 
                  src={stone.image} 
                  alt={stone.name} 
                  className="w-full h-full object-cover"
                />
                <div 
                  className={`absolute top-2 right-2 ${getRarityColor(stone.rarity)} text-xs font-medium px-2 py-0.5 rounded-full`}
                >
                  {stone.rarity}
                </div>
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold mb-1">{stone.name}</h4>
                    <p className="text-gray-600 text-sm">{stone.estimatedValue}</p>
                  </div>
                  <div className="bg-primary-50 text-primary-700 px-2 py-1 rounded text-xs font-medium">
                    {stone.similarityScore}% match
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AlternativeStonesSection;