import React, { useState } from 'react';
import { FlaskConical, History, MapPin } from 'lucide-react';

interface StoneDetailProps {
  stone: {
    name: string;
    composition: string;
    uses: string;
    location: string;
    history: string;
  };
}

const StoneDetailSection: React.FC<StoneDetailProps> = ({ stone }) => {
  const [activeTab, setActiveTab] = useState('composition');

  const tabs = [
    { id: 'composition', label: 'Composition', icon: <FlaskConical size={18} /> },
    { id: 'history', label: 'History & Origin', icon: <History size={18} /> },
    { id: 'location', label: 'Location', icon: <MapPin size={18} /> },
  ];

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="border-b border-gray-200">
        <div className="flex">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center py-4 px-6 font-medium transition-colors ${
                activeTab === tab.id
                  ? 'text-primary-600 border-b-2 border-primary-500'
                  : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>
      </div>
      
      <div className="p-6">
        {activeTab === 'composition' && (
          <div className="animate-fade-in">
            <h3 className="text-xl font-semibold mb-4">Mineral Composition</h3>
            <p className="text-gray-700 mb-4">{stone.composition}</p>
            
            <h4 className="text-lg font-semibold mb-3 mt-6">Common Uses</h4>
            <div className="space-y-2">
              {stone.uses.split(',').map((use, index) => (
                <div key={index} className="flex items-start">
                  <div className="h-6 w-6 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center mr-3 mt-0.5">
                    <span className="text-xs font-bold">{index + 1}</span>
                  </div>
                  <p className="text-gray-700">{use.trim()}</p>
                </div>
              ))}
            </div>
            
            <h4 className="text-lg font-semibold mb-3 mt-6">Physical Properties</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <span className="text-sm text-gray-500">Color</span>
                <p className="font-medium">
                  {stone.name === 'Amethyst' ? 'Purple to violet' : 
                   stone.name === 'Emerald' ? 'Medium to dark green' : 
                   stone.name === 'Ruby' ? 'Pink to blood-red' : 
                   stone.name === 'Diamond' ? 'Typically colorless to yellow' : 'Various'}
                </p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <span className="text-sm text-gray-500">Crystal Structure</span>
                <p className="font-medium">
                  {stone.name === 'Amethyst' ? 'Trigonal' : 
                   stone.name === 'Emerald' ? 'Hexagonal' : 
                   stone.name === 'Ruby' ? 'Trigonal' : 
                   stone.name === 'Diamond' ? 'Cubic' : 'Various'}
                </p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <span className="text-sm text-gray-500">Specific Gravity</span>
                <p className="font-medium">
                  {stone.name === 'Amethyst' ? '2.65' : 
                   stone.name === 'Emerald' ? '2.67-2.78' : 
                   stone.name === 'Ruby' ? '3.97-4.05' : 
                   stone.name === 'Diamond' ? '3.5-3.53' : '2.5-3.0'}
                </p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <span className="text-sm text-gray-500">Refractive Index</span>
                <p className="font-medium">
                  {stone.name === 'Amethyst' ? '1.544-1.553' : 
                   stone.name === 'Emerald' ? '1.57-1.58' : 
                   stone.name === 'Ruby' ? '1.762-1.778' : 
                   stone.name === 'Diamond' ? '2.417-2.419' : '1.5-1.7'}
                </p>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'history' && (
          <div className="animate-fade-in">
            <h3 className="text-xl font-semibold mb-4">Historical Significance</h3>
            <p className="text-gray-700 mb-6 leading-relaxed">{stone.history}</p>
            
            <div className="border-l-4 border-primary-500 pl-4 py-2 bg-primary-50 rounded-r-lg">
              <h4 className="font-semibold mb-2">Cultural Significance</h4>
              <p className="text-gray-700 text-sm">
                {stone.name === 'Amethyst' 
                  ? 'Amethyst has been associated with clarity of thought, sobriety, and spiritual insight in many cultures. It was highly valued by ancient Greeks and Romans and later became associated with royalty and religious authority in medieval Europe.'
                  : stone.name === 'Emerald'
                    ? 'Emeralds have been symbols of rebirth, fertility, and eternal youth. In many cultures, they were believed to reveal truth and protect against evil spells. Cleopatra was so fascinated by emeralds that she claimed ownership of all emerald mines in Egypt.'
                    : stone.name === 'Ruby'
                      ? 'Rubies have symbolized passion, protection, and prosperity. In ancient India, they were called "ratnaraj" (king of precious stones). Ancient Burmese warriors believed that rubies made them invincible in battle.'
                      : stone.name === 'Diamond'
                        ? 'Diamonds have represented invincibility, purity, and eternal love. Ancient Greeks believed they were tears of the gods, while ancient Indians thought they were created when lightning struck rocks. The tradition of diamond engagement rings was popularized by a De Beers marketing campaign in the 20th century.'
                        : 'This stone has held significant cultural value throughout history, with various beliefs about its metaphysical properties and uses in ceremonial contexts.'}
              </p>
            </div>
          </div>
        )}
        
        {activeTab === 'location' && (
          <div className="animate-fade-in">
            <h3 className="text-xl font-semibold mb-4">Geographic Distribution</h3>
            <p className="text-gray-700 mb-6">
              {stone.name} can be found in various locations around the world, with 
              significant deposits in the following regions:
            </p>
            
            <div className="space-y-4">
              {stone.location.split(',').map((location, index) => (
                <div key={index} className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">{location.trim()}</h4>
                  <p className="text-gray-700 text-sm">
                    {location.includes('Brazil') 
                      ? 'Brazil is home to some of the world\'s largest deposits, particularly in the states of Minas Gerais, Bahia, and Rio Grande do Sul.'
                      : location.includes('Colombia') 
                        ? 'Colombian emeralds are considered among the finest in the world, with major mining areas in Muzo, Chivor, and Coscuez.'
                        : location.includes('Myanmar') 
                          ? 'Known historically as Burma, Myanmar produces some of the world\'s finest rubies from the Mogok Stone Tract.'
                          : location.includes('South Africa') 
                            ? 'South Africa became a major diamond producer following discoveries in Kimberley in the late 19th century.'
                            : location.includes('Uruguay') 
                              ? 'Uruguay\'s Artigas region is known for its high-quality amethyst geodes.'
                              : location.includes('Zambia') 
                                ? 'Zambia has become one of the world\'s major sources of high-quality emeralds.'
                                : location.includes('Thailand') 
                                  ? 'Thailand is known for its ruby deposits, particularly in the Chanthaburi and Trat provinces.'
                                  : location.includes('Russia') 
                                    ? 'Russia is a major producer of diamonds, with significant mines in Siberia.'
                                    : `This region contains significant deposits of ${stone.name}, contributing to the global supply.`}
                  </p>
                </div>
              ))}
            </div>
            
            <div className="mt-6">
              <h4 className="text-lg font-semibold mb-3">Mining Methods</h4>
              <p className="text-gray-700">
                {stone.name === 'Amethyst' 
                  ? 'Amethyst is typically extracted through open-pit mining. Large geodes containing amethyst crystals are carefully extracted and processed to preserve the crystal formations.'
                  : stone.name === 'Emerald' 
                    ? 'Emerald mining is often done through shaft mining, where vertical tunnels are dug into the earth to reach emerald-bearing rock. The rock is then carefully broken apart to extract the emeralds.'
                    : stone.name === 'Ruby' 
                      ? 'Ruby mining methods include both open-pit mining and shaft mining. In some regions, rubies are also extracted from river gravels through alluvial mining.'
                      : stone.name === 'Diamond' 
                        ? 'Diamonds are mined through various methods including open-pit mining, underground mining, and alluvial mining in riverbeds. Modern mining operations often use advanced technology to sort and identify diamonds.'
                        : 'This stone is extracted using various mining techniques including open-pit mining, shaft mining, and in some cases, alluvial mining in riverbeds.'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StoneDetailSection;