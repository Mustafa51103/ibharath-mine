import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface StoneRarityChartProps {
  stoneName: string;
}

const StoneRarityChart: React.FC<StoneRarityChartProps> = ({ stoneName }) => {
  // Sample data - in a real app, this would come from an API
  const getChartData = () => {
    // Generate some random data based on the stone name for demo purposes
    const years = ['2019', '2020', '2021', '2022', '2023', '2024'];
    
    let valueData;
    let rarityData;
    
    switch (stoneName) {
      case 'Amethyst':
        valueData = [20, 22, 25, 23, 28, 30];
        rarityData = [0.3, 0.28, 0.25, 0.27, 0.24, 0.22];
        break;
      case 'Emerald':
        valueData = [600, 700, 850, 900, 1100, 1200];
        rarityData = [0.6, 0.62, 0.64, 0.68, 0.7, 0.73];
        break;
      case 'Ruby':
        valueData = [1200, 1500, 1800, 2100, 2400, 2800];
        rarityData = [0.75, 0.77, 0.8, 0.82, 0.85, 0.87];
        break;
      case 'Diamond':
        valueData = [8000, 10000, 15000, 20000, 25000, 30000];
        rarityData = [0.9, 0.91, 0.92, 0.93, 0.94, 0.95];
        break;
      default:
        valueData = [50, 55, 60, 65, 70, 75];
        rarityData = [0.5, 0.52, 0.54, 0.56, 0.58, 0.6];
    }
    
    return {
      labels: years,
      datasets: [
        {
          label: 'Average Value (USD)',
          data: valueData,
          borderColor: 'rgb(99, 102, 241)',
          backgroundColor: 'rgba(99, 102, 241, 0.1)',
          tension: 0.4,
          fill: false,
          yAxisID: 'y',
        },
        {
          label: 'Rarity Index',
          data: rarityData,
          borderColor: 'rgb(245, 158, 11)',
          backgroundColor: 'rgba(245, 158, 11, 0.1)',
          tension: 0.4,
          fill: false,
          yAxisID: 'y1',
        },
      ],
    };
  };

  const options = {
    responsive: true,
    interaction: {
      mode: 'index' as const,
      intersect: false,
    },
    scales: {
      y: {
        type: 'linear' as const,
        display: true,
        position: 'left' as const,
        title: {
          display: true,
          text: 'Value (USD)',
        },
        ticks: {
          callback: function(value: any) {
            if (stoneName === 'Diamond') {
              return '$' + value.toLocaleString();
            }
            return '$' + value;
          }
        }
      },
      y1: {
        type: 'linear' as const,
        display: true,
        position: 'right' as const,
        title: {
          display: true,
          text: 'Rarity Index (0-1)',
        },
        min: 0,
        max: 1,
        grid: {
          drawOnChartArea: false,
        },
      },
    },
    plugins: {
      legend: {
        position: 'bottom' as const,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.dataset.yAxisID === 'y') {
              return label + '$' + context.parsed.y;
            } else {
              return label + context.parsed.y.toFixed(2);
            }
          }
        }
      }
    },
  };

  return <Line options={options} data={getChartData()} />;
};

export default StoneRarityChart;