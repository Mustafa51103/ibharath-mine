import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, Menu, X, Mic, Gem } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Gem size={28} className="text-primary-500" />
            <span className="font-bold text-xl">IBHARATH MINE</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link
              to="/"
              className={`font-medium transition-colors ${
                location.pathname === '/' ? 'text-primary-500' : 'text-gray-700 hover:text-primary-500'
              }`}
            >
              Home
            </Link>
            <Link
              to="/compare"
              className={`font-medium transition-colors ${
                location.pathname === '/compare' ? 'text-primary-500' : 'text-gray-700 hover:text-primary-500'
              }`}
            >
              Compare
            </Link>
            <Link
              to="/collection"
              className={`font-medium transition-colors ${
                location.pathname === '/collection' ? 'text-primary-500' : 'text-gray-700 hover:text-primary-500'
              }`}
            >
              My Collection
            </Link>
            <Link
              to="/chat"
              className={`font-medium transition-colors ${
                location.pathname === '/chat' ? 'text-primary-500' : 'text-gray-700 hover:text-primary-500'
              }`}
            >
              Chat
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <button className="text-gray-600 hover:text-primary-500 transition-colors" aria-label="Search">
              <Search size={20} />
            </button>
            <button className="text-gray-600 hover:text-primary-500 transition-colors" aria-label="Voice search">
              <Mic size={20} />
            </button>
            <button
              className="md:hidden text-gray-600 hover:text-primary-500 transition-colors"
              onClick={toggleMobileMenu}
              aria-label="Toggle mobile menu"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white shadow-lg animate-fade-in">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <Link
              to="/"
              className={`py-2 font-medium ${
                location.pathname === '/' ? 'text-primary-500' : 'text-gray-700'
              }`}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/compare"
              className={`py-2 font-medium ${
                location.pathname === '/compare' ? 'text-primary-500' : 'text-gray-700'
              }`}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Compare
            </Link>
            <Link
              to="/collection"
              className={`py-2 font-medium ${
                location.pathname === '/collection' ? 'text-primary-500' : 'text-gray-700'
              }`}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              My Collection
            </Link>
            <Link
              to="/chat"
              className={`py-2 font-medium ${
                location.pathname === '/chat' ? 'text-primary-500' : 'text-gray-700'
              }`}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Chat
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;