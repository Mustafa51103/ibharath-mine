import React from 'react';
import { Link } from 'react-router-dom';
import { Star, DollarSign } from 'lucide-react';

interface SampleStone {
  id: number;
  name: string;
  image: string;
  rarity: 'Common' | 'Rare' | 'Very Rare' | 'Legendary';
  estimatedValue: string;
  location: string;
  category: 'Igneous' | 'Sedimentary' | 'Metamorphic' | 'Mineral' | 'Gemstone';
  description: string;
}

const sampleStones: SampleStone[] = [
  {
    id: 1,
    name: 'Diamond',
    image: 'https://images.pexels.com/photos/68740/diamond-gem-cubic-zirconia-jewel-68740.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Legendary',
    estimatedValue: '$5,000-$50,000',
    location: 'South Africa',
    category: 'Gemstone',
    description: 'The hardest natural material, formed under extreme pressure'
  },
  {
    id: 2,
    name: 'Granite',
    image: 'https://images.pexels.com/photos/1029604/pexels-photo-1029604.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Common',
    estimatedValue: '$10-$30',
    location: 'Worldwide',
    category: 'Igneous',
    description: 'Coarse-grained intrusive rock with visible crystals'
  },
  {
    id: 3,
    name: 'Ruby',
    image: 'https://images.pexels.com/photos/4940404/pexels-photo-4940404.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Very Rare',
    estimatedValue: '$1,000-$3,000',
    location: 'Myanmar',
    category: 'Gemstone',
    description: 'Red variety of corundum, prized for its deep color'
  },
  {
    id: 4,
    name: 'Marble',
    image: 'https://images.pexels.com/photos/5368743/pexels-photo-5368743.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Rare',
    estimatedValue: '$50-$200',
    location: 'Italy',
    category: 'Metamorphic',
    description: 'Metamorphosed limestone with distinctive swirls'
  },
  {
    id: 5,
    name: 'Amethyst',
    image: 'https://images.pexels.com/photos/5368818/pexels-photo-5368818.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Common',
    estimatedValue: '$20-$50',
    location: 'Brazil',
    category: 'Mineral',
    description: 'Purple variety of quartz, popular in jewelry'
  },
  {
    id: 6,
    name: 'Limestone',
    image: 'https://images.pexels.com/photos/5368778/pexels-photo-5368778.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rarity: 'Common',
    estimatedValue: '$5-$20',
    location: 'Global',
    category: 'Sedimentary',
    description: 'Sedimentary rock composed mainly of calcium carbonate'
  }
];

const getRarityColor = (rarity: string) => {
  switch (rarity) {
    case 'Common':
      return 'bg-gray-500';
    case 'Rare':
      return 'bg-blue-500';
    case 'Very Rare':
      return 'bg-purple-500';
    case 'Legendary':
      return 'bg-amber-500';
    default:
      return 'bg-gray-500';
  }
};

const getCategoryColor = (category: string) => {
  switch (category) {
    case 'Igneous':
      return 'bg-red-100 text-red-800';
    case 'Sedimentary':
      return 'bg-amber-100 text-amber-800';
    case 'Metamorphic':
      return 'bg-green-100 text-green-800';
    case 'Mineral':
      return 'bg-blue-100 text-blue-800';
    case 'Gemstone':
      return 'bg-purple-100 text-purple-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

const SampleStones: React.FC = () => {
  return (
    <div>
      <h3 className="text-xl font-semibold text-center mb-8">Example Stones</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {sampleStones.map(stone => (
          <Link to={`/stone/${stone.id}`} key={stone.id}>
            <div className="stone-card bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all">
              <div className="relative h-48">
                <img 
                  src={stone.image} 
                  alt={stone.name} 
                  className="w-full h-full object-cover"
                />
                <div className={`absolute top-3 right-3 ${getRarityColor(stone.rarity)} text-white text-xs font-medium px-2 py-1 rounded-full`}>
                  {stone.rarity}
                </div>
                <div className={`absolute top-3 left-3 ${getCategoryColor(stone.category)} text-xs font-medium px-2 py-1 rounded-full`}>
                  {stone.category}
                </div>
              </div>
              <div className="p-4">
                <h4 className="text-lg font-semibold mb-2">{stone.name}</h4>
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">{stone.description}</p>
                <div className="flex justify-between text-sm text-gray-600 mb-3">
                  <div className="flex items-center">
                    <DollarSign size={14} className="mr-1" />
                    {stone.estimatedValue}
                  </div>
                  <div>{stone.location}</div>
                </div>
                <div className="flex items-center text-gray-500 text-sm mt-2">
                  <div className="flex">
                    {Array.from({ length: stone.rarity === 'Common' ? 1 
                      : stone.rarity === 'Rare' ? 2 
                      : stone.rarity === 'Very Rare' ? 3 
                      : 4 }).map((_, i) => (
                      <Star key={i} size={14} className="fill-current text-amber-400" />
                    ))}
                  </div>
                  <span className="ml-auto text-blue-500 hover:text-blue-700">View details</span>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default SampleStones;