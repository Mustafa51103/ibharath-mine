import React from 'react';
import { Search, BookOpen, DollarSign, ArrowRight } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 text-white overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{ 
          backgroundImage: 'url("https://images.pexels.com/photos/1029604/pexels-photo-1029604.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          mixBlendMode: 'overlay'
        }}></div>
      </div>
      
      <div className="container mx-auto px-4 py-20 md:py-28 relative z-10">
        <div className="max-w-3xl">
          <span className="inline-block px-3 py-1 rounded-full bg-primary-500 bg-opacity-20 text-primary-400 text-sm font-medium mb-6">
            Next-Gen Stone Identification
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 animate-slide-up">
            Discover the History and Value of Your Precious Stones
          </h1>
          <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Upload a photo and let our AI identify your gems and minerals, 
            revealing their origin, composition, rarity, and estimated value.
          </p>
          
          <div className="flex flex-wrap gap-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <a 
              href="#identify" 
              className="px-6 py-3 bg-primary-500 hover:bg-primary-600 rounded-lg font-medium transition-colors flex items-center gap-2"
            >
              <Search size={18} />
              Identify a Stone
            </a>
            <a 
              href="/chat" 
              className="px-6 py-3 bg-transparent hover:bg-white hover:bg-opacity-10 border border-white border-opacity-30 rounded-lg font-medium transition-colors"
            >
              Try AI Assistant
            </a>
          </div>
        </div>
      </div>
      
      {/* Stats */}
      <div className="bg-gray-800 bg-opacity-70 py-8 relative z-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div className="p-4">
              <div className="text-3xl font-bold mb-2 text-primary-400">10,000+</div>
              <p className="text-gray-300">Stones in Database</p>
            </div>
            <div className="p-4">
              <div className="text-3xl font-bold mb-2 text-primary-400">98%</div>
              <p className="text-gray-300">Identification Accuracy</p>
            </div>
            <div className="p-4">
              <div className="text-3xl font-bold mb-2 text-primary-400">5,000+</div>
              <p className="text-gray-300">Daily Users</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;