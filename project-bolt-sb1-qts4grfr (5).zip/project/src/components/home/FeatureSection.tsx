import React from 'react';
import { PanelTop, RefreshCcw, Heart, Upload, BarChart3, MessageSquare } from 'lucide-react';

const features = [
  {
    icon: <PanelTop className="w-10 h-10 text-primary-500" />,
    title: 'Compare Stones',
    description: 'Compare up to 3 stones side by side to analyze differences in rarity, value, and composition.'
  },
  {
    icon: <Heart className="w-10 h-10 text-primary-500" />,
    title: 'Save to Collection',
    description: 'Build your personal collection by saving stones you\'ve identified or ones you\'re interested in.'
  },
  {
    icon: <BarChart3 className="w-10 h-10 text-primary-500" />,
    title: 'Rarity Trends',
    description: 'View historical trends showing how a stone\'s rarity and value have changed over time.'
  },
  {
    icon: <RefreshCcw className="w-10 h-10 text-primary-500" />,
    title: 'Alternative Suggestions',
    description: 'Discover similar stones that might offer better value or complement your collection.'
  },
  {
    icon: <Upload className="w-10 h-10 text-primary-500" />,
    title: 'Batch Upload',
    description: 'Identify multiple stones at once by uploading several images in a single session.'
  },
  {
    icon: <MessageSquare className="w-10 h-10 text-primary-500" />,
    title: 'Expert AI Chat',
    description: 'Get answers to specific questions about any stone, its value, or geological information.'
  }
];

const FeatureSection: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Powerful Features for Stone Enthusiasts</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            Our platform offers comprehensive tools to identify, study, and track your stone collection,
            all powered by advanced AI technology.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="p-6 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <a 
            href="/chat" 
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary-500 hover:bg-primary-600 text-white rounded-lg font-medium transition-colors"
          >
            Explore All Features
          </a>
        </div>
      </div>
    </section>
  );
};

export default FeatureSection;